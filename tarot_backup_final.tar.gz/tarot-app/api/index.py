from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
import httpx
import re
import json
import base64
import hmac
import hashlib
import os
from urllib.parse import parse_qsl, urlparse

app = FastAPI()

OPENROUTER_KEY = "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"

class DrawRequest(BaseModel):
    vk_sign: str
    vk_id: int
    card_index: int
    question: str = ""

def is_valid_response(text: str) -> bool:
    if not text: return False
    # Вырезаем <think> теги
    text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL)
    text = text.replace('<think>', '').replace('</think>', '')
    
    # Ищем азиатские иероглифы (Китайский, Японский, Корейский)
    if re.search(r'[\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]', text): 
        return False 
        
    # Проверяем соотношение кириллицы
    letters = re.sub(r'[^a-zA-Zа-яА-ЯёЁ]', '', text)
    if not letters: 
        return True
        
    ru_letters = re.findall(r'[а-яА-ЯёЁ]', letters)
    if len(letters) > 0 and len(ru_letters) / len(letters) < 0.6: 
        return False 
        
    return True

@app.post("/api/draw")
async def draw_card(req: DrawRequest):
    ai_response = ""
    refund = False
    
    try:
        if req.question:
            async with httpx.AsyncClient() as client:
                headers = {
                    "Authorization": f"Bearer {OPENROUTER_KEY}",
                    "HTTP-Referer": "https://vk.com/app54632741",
                    "Content-Type": "application/json"
                }
                
                system_prompt = (
                    "Ты — древний мистический дух Таро. Твоя задача — давать короткие, мудрые предсказания СТРОГО на русском языке. "
                    "ЗАПРЕЩЕНО использовать английский, китайский или другие языки. ЗАПРЕЩЕНО использовать Markdown (никаких звездочек). "
                    "Если вопрос пользователя странный, смешной или состоит из одного слова/междометия, "
                    "НИКАК не комментируй само слово, а просто проигнорируй его и дай таинственный совет на будущее, опираясь на вытянутую карту. "
                    "Твой ответ должен быть не длиннее 1-2 предложений."
                )
                
                payload = {
                    "model": "openrouter/free",
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": f"Я вытянул карту номер {req.card_index}. Мой вопрос: '{req.question}'. Что скажут духи?"}
                    ]
                }
                
                success = False
                for attempt in range(3):
                    try:
                        resp = await client.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=payload, timeout=12.0)
                        if resp.status_code == 200:
                            data = resp.json()
                            text = data['choices'][0]['message']['content']
                            text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL).replace('<think>', '').replace('</think>', '')
                            text = text.replace('*', '').strip()
                            
                            if is_valid_response(text):
                                ai_response = text
                                success = True
                                break
                    except Exception as e:
                        print(f"Error on attempt {attempt}: {e}")
                
                if not success:
                    ai_response = "Духи не смогли разобрать твой вопрос. Сосредоточься и спроси иначе."
                    refund = True
    except Exception as base_e:
        ai_response = f"Связь прервалась ({str(base_e)})"
        refund = True

    return {
        "status": "success",
        "ai_text": ai_response,
        "refund": refund
    }
