#!/bin/bash
npx vercel --prod --token $VERCEL_TOKEN
